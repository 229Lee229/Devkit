Keep all .dll files in the same folder.
Just double click 'HyperTrm.exe' to run the terminal.
Enjoy !!

visit us again at www.worthysolution.blogspot.com